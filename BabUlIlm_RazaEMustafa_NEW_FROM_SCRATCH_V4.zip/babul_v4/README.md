# Bab Ul Ilm Raza E Mustafa — New Native UI/UX v4

A completely redesigned Android app experience. This version uses a fresh native app shell, new navigation, new dashboard, new visual identity, splash screen, logo, Explore, Profile and app-style entry points. Website pages remain available inside the app when deeper content/services are needed.

Build: `gradle :app:assembleDebug --no-daemon`
