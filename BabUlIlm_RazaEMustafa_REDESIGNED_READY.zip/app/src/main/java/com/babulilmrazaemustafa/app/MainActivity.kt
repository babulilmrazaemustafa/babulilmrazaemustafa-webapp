package com.babulilmrazaemustafa.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import android.graphics.drawable.GradientDrawable

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progress: ProgressBar
    private lateinit var titleText: TextView
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val homeUrl = "https://babulilmrazaemustafa.org.in/"
    private val internalHost = "babulilmrazaemustafa.org.in"
    private val filePickerRequest = 1001

    private val navy = Color.rgb(18, 28, 45)
    private val ink = Color.rgb(31, 41, 55)
    private val ivory = Color.rgb(250, 248, 242)
    private val accent = Color.rgb(20, 130, 126)
    private val muted = Color.rgb(107, 114, 128)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(ivory)
        }

        root.addView(createTopBar(), LinearLayout.LayoutParams(-1, dp(74)))

        val content = FrameLayout(this)
        swipeRefresh = SwipeRefreshLayout(this)
        swipeRefresh.setColorSchemeColors(accent)
        content.addView(swipeRefresh, FrameLayout.LayoutParams(-1, -1))

        webView = WebView(this)
        swipeRefresh.addView(webView, ViewGroup.LayoutParams(-1, -1))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressDrawable = getDrawable(android.R.drawable.progress_horizontal)
        }
        content.addView(progress, FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP))

        val error = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(30), dp(30), dp(30), dp(30))
            setBackgroundColor(ivory)
            visibility = View.GONE
            addView(TextView(this@MainActivity).apply {
                text = "Connection unavailable"
                textSize = 21f
                setTextColor(ink)
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
            })
            addView(TextView(this@MainActivity).apply {
                text = "Please check your internet connection and try again."
                textSize = 14f
                setTextColor(muted)
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(18))
            })
            addView(Button(this@MainActivity).apply {
                text = "TRY AGAIN"
                setTextColor(Color.WHITE)
                background = pill(accent)
                setOnClickListener { loadHome() }
            }, LinearLayout.LayoutParams(-2, dp(48)))
        }
        content.addView(error, FrameLayout.LayoutParams(-1, -1))
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(createBottomBar(), LinearLayout.LayoutParams(-1, dp(76)))

        setContentView(root)
        configureWebView(error)
        swipeRefresh.setOnRefreshListener { webView.reload() }
        loadHome()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun createTopBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(12), dp(8))
            setBackgroundColor(navy)
        }
        val mark = TextView(this).apply {
            text = "ب"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.create("serif", Typeface.BOLD)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(accent)
            }
        }
        bar.addView(mark, LinearLayout.LayoutParams(dp(46), dp(46)))

        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(8), 0)
        }
        titleText = TextView(this).apply {
            text = "Bab Ul Ilm"
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
        }
        titles.addView(titleText)
        titles.addView(TextView(this).apply {
            text = "Raza E Mustafa"
            textSize = 11.5f
            setTextColor(Color.rgb(196, 205, 218))
        })
        bar.addView(titles, LinearLayout.LayoutParams(0, -1, 1f))

        val refresh = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_popup_sync)
            setColorFilter(Color.WHITE)
            background = transparent()
            contentDescription = "Refresh"
            setOnClickListener { webView.reload() }
        }
        bar.addView(refresh, LinearLayout.LayoutParams(dp(48), dp(48)))
        return bar
    }

    private fun createBottomBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(5), dp(6), dp(5))
            setBackgroundColor(Color.WHITE)
        }
        nav(bar, "⌂", "Home") { webView.loadUrl(homeUrl) }
        nav(bar, "▤", "Library") { webView.loadUrl(homeUrl + "#elibrary") }
        nav(bar, "✦", "Programs") { webView.loadUrl(homeUrl + "#programs") }
        nav(bar, "✉", "Contact") { webView.loadUrl(homeUrl + "#contact") }
        return bar
    }

    private fun nav(bar: LinearLayout, icon: String, label: String, action: () -> Unit) {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, dp(2), 0, dp(2))
            setOnClickListener { action() }
        }
        item.addView(TextView(this).apply {
            text = icon
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(accent)
        })
        item.addView(TextView(this).apply {
            text = label
            textSize = 10.5f
            gravity = Gravity.CENTER
            setTextColor(ink)
            setTypeface(typeface, Typeface.BOLD)
        })
        bar.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(errorView: View) {
        webView.setBackgroundColor(ivory)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            userAgentString = userAgentString + " BabUlIlmAndroidApp/3.0"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val host = uri.host ?: ""
                return if (uri.scheme == "http" || uri.scheme == "https") {
                    if (host == internalHost || host.endsWith(".$internalHost")) false
                    else { openExternal(uri); true }
                } else { openExternal(uri); true }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                errorView.visibility = View.GONE
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                swipeRefresh.isRefreshing = false
                progress.visibility = View.GONE
                applyAppTheme()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                if (request?.isForMainFrame == true) {
                    swipeRefresh.isRefreshing = false
                    progress.visibility = View.GONE
                    errorView.visibility = View.VISIBLE
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent()
                        ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                            type = "*/*"
                            addCategory(Intent.CATEGORY_OPENABLE)
                        }
                    startActivityForResult(intent, filePickerRequest)
                    true
                } catch (_: Exception) {
                    fileCallback = null
                    false
                }
            }
        }
    }

    private fun applyAppTheme() {
        val css = """
            (function(){
              var s=document.getElementById('bab-ul-ilm-app-theme');
              if(!s){s=document.createElement('style');s.id='bab-ul-ilm-app-theme';document.head.appendChild(s);}
              s.textContent=`
                :root{--app-navy:#121c2d!important;--app-accent:#14827e!important;--app-ivory:#faf8f2!important;}
                html,body{background:var(--app-ivory)!important;}
                body{padding-bottom:12px!important;}
                header,nav{ }
                body>header,body>nav{display:none!important;}
                footer{ }
                .container,.section-container{max-width:100%!important;}
                section{border-radius:22px!important;}
                button,.btn,.button{border-radius:14px!important;}
                input,select,textarea{border-radius:14px!important;}
                img{max-width:100%;}
              `;
            })();
        """.trimIndent()
        webView.evaluateJavascript(css, null)
    }

    private fun loadHome() {
        webView.loadUrl(homeUrl)
    }

    private fun openExternal(uri: Uri) {
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun pill(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(14).toFloat()
    }

    private fun transparent() = GradientDrawable().apply {
        setColor(Color.TRANSPARENT)
        cornerRadius = dp(24).toFloat()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == filePickerRequest) {
            val result = if (resultCode == Activity.RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            fileCallback?.onReceiveValue(result)
            fileCallback = null
        }
    }

    override fun onDestroy() {
        fileCallback?.onReceiveValue(null)
        fileCallback = null
        webView.destroy()
        super.onDestroy()
    }
}
