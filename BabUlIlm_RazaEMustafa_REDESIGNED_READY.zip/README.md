# Bab Ul Ilm Raza E Mustafa — Android App (Redesigned)

This package is based on the supplied working Android WebView project.

## What is preserved
- Existing website/backend URL and live data
- Website forms, registration, library, gallery, donation, contact and portal links
- WebView JavaScript, cookies, DOM storage and file upload support
- Back navigation, pull-to-refresh and offline/error handling
- Existing GitHub Actions build approach

## What is redesigned
- New dark Islamic-inspired app chrome
- New custom app icon
- New top app bar
- New bottom navigation
- Ivory/navy/teal visual system
- Rounded modern controls and refreshed WebView presentation
- App branding separated from the website's old wrapper

## Build
Use the supplied GitHub Actions workflow or run:
`gradle :app:assembleDebug --no-daemon`

The APK is generated at:
`app/build/outputs/apk/debug/app-debug.apk`
