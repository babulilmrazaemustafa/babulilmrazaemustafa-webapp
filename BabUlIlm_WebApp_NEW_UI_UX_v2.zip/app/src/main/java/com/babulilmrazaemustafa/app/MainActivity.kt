package com.babulilmrazaemustafa.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import android.graphics.drawable.GradientDrawable

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progress: ProgressBar
    private lateinit var errorView: TextView
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val homeUrl = "https://babulilmrazaemustafa.org.in/"
    private val internalHost = "babulilmrazaemustafa.org.in"
    private val filePickerRequest = 1001

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(23, 32, 51)
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247, 249, 252))
        }
        root.addView(createTopBar(), LinearLayout.LayoutParams(-1, dp(68)))

        val content = FrameLayout(this)
        swipeRefresh = SwipeRefreshLayout(this)
        swipeRefresh.setColorSchemeColors(Color.rgb(15, 118, 110))
        content.addView(swipeRefresh, FrameLayout.LayoutParams(-1, -1))

        webView = WebView(this)
        swipeRefresh.addView(webView, ViewGroup.LayoutParams(-1, -1))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressDrawable = getDrawable(android.R.drawable.progress_horizontal)
        }
        val pp = FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP)
        content.addView(progress, pp)

        errorView = TextView(this).apply {
            text = "Unable to load the website\n\nTap here to try again"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(51, 65, 85))
            setBackgroundColor(Color.rgb(247, 249, 252))
            visibility = View.GONE
            setOnClickListener { loadHome() }
        }
        content.addView(errorView, FrameLayout.LayoutParams(-1, -1))
        root.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(createBottomBar(), LinearLayout.LayoutParams(-1, dp(68)))

        setContentView(root)
        configureWebView()
        swipeRefresh.setOnRefreshListener { webView.reload() }
        loadHome()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    private fun createTopBar(): View {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(10), 0)
            setBackgroundColor(Color.WHITE)
        }
        val logo = ImageView(this).apply {
            setImageResource(com.babulilmrazaemustafa.app.R.drawable.ic_app_logo)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        bar.addView(logo, LinearLayout.LayoutParams(dp(44), dp(44)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10),0,0,0) }
        titles.addView(TextView(this).apply { text = "Bab Ul Ilm"; textSize = 18f; setTextColor(Color.rgb(23,32,51)); setTypeface(typeface, android.graphics.Typeface.BOLD) })
        titles.addView(TextView(this).apply { text = "Raza E Mustafa"; textSize = 12f; setTextColor(Color.rgb(100,116,139)) })
        bar.addView(titles, LinearLayout.LayoutParams(0, -1, 1f))
        val refresh = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_popup_sync)
            setColorFilter(Color.rgb(23,32,51))
            background = transparentSelectable()
            contentDescription = "Refresh"
            setOnClickListener { webView.reload() }
        }
        bar.addView(refresh, LinearLayout.LayoutParams(dp(48), dp(48)))
        return bar
    }

    private fun createBottomBar(): View {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setBackgroundColor(Color.WHITE) }
        addNavItem(bar, "⌂", "Home") { webView.loadUrl(homeUrl) }
        addNavItem(bar, "▦", "About") { webView.loadUrl(homeUrl + "#about") }
        addNavItem(bar, "▤", "Programs") { webView.loadUrl(homeUrl + "#programs") }
        addNavItem(bar, "✉", "Contact") { webView.loadUrl(homeUrl + "#contact") }
        return bar
    }

    private fun addNavItem(bar: LinearLayout, icon: String, label: String, action: () -> Unit) {
        val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setOnClickListener { action() } }
        item.addView(TextView(this).apply { text = icon; textSize = 21f; gravity = Gravity.CENTER; setTextColor(Color.rgb(15,118,110)) })
        item.addView(TextView(this).apply { text = label; textSize = 11f; gravity = Gravity.CENTER; setTextColor(Color.rgb(71,85,105)) })
        bar.addView(item, LinearLayout.LayoutParams(0, -1, 1f))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            builtInZoomControls = false
            displayZoomControls = false
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            userAgentString = userAgentString + " BabUlIlmAndroidApp/2.0"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val host = uri.host ?: ""
                return if (uri.scheme == "http" || uri.scheme == "https") {
                    if (host == internalHost || host.endsWith(".$internalHost")) false else { openExternal(uri); true }
                } else { openExternal(uri); true }
            }
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                errorView.visibility = View.GONE; progress.visibility = View.VISIBLE
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                swipeRefresh.isRefreshing = false; progress.visibility = View.GONE
            }
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                if (request?.isForMainFrame == true) { swipeRefresh.isRefreshing = false; progress.visibility = View.GONE; errorView.visibility = View.VISIBLE }
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress; progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
            }
            override fun onShowFileChooser(webView: WebView?, filePathCallback: ValueCallback<Array<Uri>>?, fileChooserParams: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null); fileCallback = filePathCallback
                return try {
                    val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
                    startActivityForResult(intent, filePickerRequest); true
                } catch (_: Exception) { fileCallback = null; false }
            }
        }
    }

    private fun loadHome() { errorView.visibility = View.GONE; webView.loadUrl(homeUrl) }
    private fun openExternal(uri: Uri) { try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {} }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun transparentSelectable(): GradientDrawable = GradientDrawable().apply { setColor(Color.TRANSPARENT); cornerRadius = dp(24).toFloat() }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == filePickerRequest) {
            val result = if (resultCode == Activity.RESULT_OK && data?.data != null) arrayOf(data.data!!) else null
            fileCallback?.onReceiveValue(result); fileCallback = null
        }
    }
    override fun onDestroy() { fileCallback?.onReceiveValue(null); fileCallback = null; webView.destroy(); super.onDestroy() }
}
