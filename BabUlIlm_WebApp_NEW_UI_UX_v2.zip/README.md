# Bab Ul Ilm WebApp (No Logo)

Android WebView app for https://babulilmrazaemustafa.org.in/

## Build
This is a standard Android Gradle project. It builds a debug APK with Gradle 8.9 and JDK 17.

## If uploading this project as a ZIP to GitHub
GitHub stores ZIP files as ZIP files and does not automatically treat the ZIP contents as a source tree. If your repository is intended to contain only this ZIP, create the separate GitHub Actions workflow provided as `build-from-uploaded-zip.yml` in `.github/workflows/`. That workflow extracts the uploaded ZIP and builds the APK.

## App
- No logo in the app UI
- WebView opens babulilmrazaemustafa.org.in
- Back navigation
- Pull-to-refresh
- Loading indicator
- Offline screen
- File upload support
