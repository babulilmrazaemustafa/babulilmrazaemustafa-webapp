# Bab Ul Ilm Raza E Mustafa — V6

Fresh native-style Android app shell based on the V5 visual direction, with a more reliable GitHub Actions build configuration.

Application ID: `com.babulilmrazaemustafa.app`
Website: `https://babulilmrazaemustafa.org.in/`
