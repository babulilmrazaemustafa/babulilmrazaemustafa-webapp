package com.babulilmrazaemustafa.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var title: TextView
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private val uploadCode = 4101
    private val site = "https://babulilmrazaemustafa.org.in/"
    private val host = "babulilmrazaemustafa.org.in"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(248,247,244)
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        build()
    }

    private fun build() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(248,247,244)) }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(10), dp(14), dp(10)); setBackgroundColor(Color.WHITE) }
        val logo = ImageView(this).apply { setImageResource(R.drawable.ic_app_logo) }
        top.addView(logo, LinearLayout.LayoutParams(dp(42), dp(42)))
        val names = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
        names.addView(TextView(this).apply { text="BAB UL ILM"; textSize=17f; setTextColor(Color.rgb(25,27,33)); setTypeface(null,1) })
        names.addView(TextView(this).apply { text="Raza E Mustafa"; textSize=11f; setTextColor(Color.rgb(108,105,98)) })
        top.addView(names, LinearLayout.LayoutParams(0, -1, 1f))
        title = TextView(this).apply { text="Home"; textSize=12f; setTextColor(Color.rgb(94,84,190)); setTypeface(null,1); gravity=android.view.Gravity.CENTER }
        top.addView(title, LinearLayout.LayoutParams(dp(58), dp(42)))
        root.addView(top, LinearLayout.LayoutParams(-1, dp(68)))

        web = WebView(this)
        configureWebView()
        root.addView(web, LinearLayout.LayoutParams(-1,0,1f))
        root.addView(bottomNav(), LinearLayout.LayoutParams(-1,dp(70)))
        setContentView(root)
        web.loadUrl(site)
    }

    private fun bottomNav(): View {
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=android.view.Gravity.CENTER;setPadding(dp(6),dp(6),dp(6),dp(7));setBackgroundColor(Color.WHITE)}
        item(bar,"⌂","Home","")
        item(bar,"◉","Learn","#programs")
        item(bar,"▤","Library","#e-library")
        item(bar,"✦","Events","#competitions")
        item(bar,"•••","More","#contact")
        return bar
    }
    private fun item(bar:LinearLayout, icon:String, label:String, fragment:String){
        val v=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=android.view.Gravity.CENTER;setOnClickListener{navigate(fragment)}}
        v.addView(TextView(this).apply{text=icon;textSize=19f;gravity=android.view.Gravity.CENTER;setTextColor(Color.rgb(94,84,190))},LinearLayout.LayoutParams(-1,dp(28)))
        v.addView(TextView(this).apply{text=label;textSize=10f;gravity=android.view.Gravity.CENTER;setTextColor(Color.rgb(82,80,76));setTypeface(null,1)},LinearLayout.LayoutParams(-1,dp(18)))
        bar.addView(v,LinearLayout.LayoutParams(0,-1,1f))
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView(){
        web.settings.javaScriptEnabled=true
        web.settings.domStorageEnabled=true
        web.settings.databaseEnabled=true
        web.settings.allowFileAccess=true
        web.settings.allowContentAccess=true
        web.settings.loadsImagesAutomatically=true
        web.settings.mixedContentMode=WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,true)
        web.setBackgroundColor(Color.rgb(248,247,244))
        web.webViewClient=object:WebViewClient(){
            override fun onPageFinished(view: WebView?, url: String?) { super.onPageFinished(view,url); injectSkin(); }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u=r.url; val h=u.host ?: ""
                if((u.scheme=="http"||u.scheme=="https") && (h==host || h.endsWith(".$host"))) return false
                try{startActivity(Intent(Intent.ACTION_VIEW,u))}catch(_:Exception){}
                return true
            }
        }
        web.webChromeClient=object:WebChromeClient(){
            override fun onShowFileChooser(v:WebView?, cb:ValueCallback<Array<Uri>>?, p:FileChooserParams?):Boolean{
                uploadCallback?.onReceiveValue(null); uploadCallback=cb
                return try{startActivityForResult(p?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE)},uploadCode);true}catch(_:Exception){uploadCallback=null;false}
            }
        }
    }

    private fun navigate(fragment:String){
        if(fragment.isEmpty()) web.loadUrl(site) else web.loadUrl(site+fragment)
    }

    private fun injectSkin(){
        val css = """
        (function(){
          const s=document.createElement('style');
          s.innerHTML=`
          :root{--ink:#191b21;--muted:#6c6962;--paper:#f8f7f4;--card:#ffffff;--violet:#5e54be;--mint:#2aa884;--line:#e7e3db;--shadow:0 10px 28px rgba(25,27,33,.07)}
          html,body{background:var(--paper)!important;color:var(--ink)!important;font-family:system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif!important}
          body{padding-bottom:18px!important}
          header,nav,footer,.navbar,.site-header,.site-footer,[class*='navbar'],[class*='header']:not(section){ }
          body>header,body>nav,body>footer{display:none!important}
          main{max-width:none!important;width:100%!important;padding:0 16px!important}
          section{border:0!important;box-shadow:none!important;background:transparent!important;margin:0 0 18px!important;padding:18px 0!important}
          section>div,.card,.program-card,.book-card,.competition-card,.gallery-card,.testimonial-card,.contact-card{border-radius:22px!important;border:1px solid var(--line)!important;background:var(--card)!important;box-shadow:var(--shadow)!important}
          h1{font-size:32px!important;line-height:1.08!important;letter-spacing:-.7px!important}
          h2{font-size:24px!important;letter-spacing:-.3px!important}
          h3{font-size:18px!important}
          p,li{color:var(--muted)!important;line-height:1.65!important}
          a,button{border-radius:14px!important}
          button,.btn,.button,[type=submit]{background:var(--violet)!important;color:#fff!important;border:0!important;padding:12px 17px!important;font-weight:700!important;box-shadow:0 7px 16px rgba(94,84,190,.18)!important}
          input,select,textarea{background:#fbfaf8!important;border:1px solid var(--line)!important;border-radius:14px!important;padding:13px 14px!important;color:var(--ink)!important;outline:none!important}
          input:focus,select:focus,textarea:focus{border-color:var(--violet)!important;box-shadow:0 0 0 3px rgba(94,84,190,.10)!important}
          img{border-radius:18px!important;max-width:100%!important}
          .hero,.hero-section{border-radius:26px!important;overflow:hidden!important}
          [class*='grid']{gap:14px!important}
          .modal{border-radius:24px!important}
          .badge,.tag{border-radius:999px!important}
          .container,.content{max-width:100%!important}
          `;
          document.head.appendChild(s);
          document.documentElement.style.scrollBehavior='smooth';
          window.scrollTo(0,0);
        })();
        """.trimIndent()
        web.evaluateJavascript(css,null)
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==uploadCode){val result=if(resultCode==Activity.RESULT_OK&&data?.data!=null)arrayOf(data.data!!)else null;uploadCallback?.onReceiveValue(result);uploadCallback=null}}
    override fun onBackPressed(){if(web.canGoBack())web.goBack() else super.onBackPressed()}
    override fun onDestroy(){uploadCallback?.onReceiveValue(null);web.destroy();super.onDestroy()}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
