package com.babulilmrazaemustafa.app

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.graphics.drawable.GradientDrawable

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var webView: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequest = 4001

    private val site = "https://babulilmrazaemustafa.org.in/"
    private val host = "babulilmrazaemustafa.org.in"
    private val ink = Color.rgb(23,26,36)
    private val muted = Color.rgb(92,97,111)
    private val paper = Color.rgb(247,248,250)
    private val surface = Color.WHITE
    private val violet = Color.rgb(101,87,217)
    private val mint = Color.rgb(31,174,138)
    private val peach = Color.rgb(242,139,114)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = paper
        window.navigationBarColor = surface
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        showSplash()
    }

    private fun showSplash() {
        val box = FrameLayout(this).apply { setBackgroundColor(violet) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val logo = ImageView(this).apply { setImageResource(R.drawable.ic_app_logo) }
        col.addView(logo, LinearLayout.LayoutParams(dp(110), dp(110)))
        col.addView(TextView(this).apply { text = "BAB UL ILM"; textSize = 25f; setTextColor(Color.WHITE); setTypeface(Typeface.DEFAULT, Typeface.BOLD); gravity = Gravity.CENTER; setPadding(0,dp(18),0,dp(2)) })
        col.addView(TextView(this).apply { text = "RAZA E MUSTAFA"; textSize = 12f; setTextColor(Color.WHITE); alpha=.82f; gravity=Gravity.CENTER })
        box.addView(col, FrameLayout.LayoutParams(-1,-1))
        setContentView(box)
        box.postDelayed({ buildApp() }, 650)
    }

    private fun buildApp() {
        root = FrameLayout(this).apply { setBackgroundColor(paper) }
        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        shell.addView(topBar(), LinearLayout.LayoutParams(-1, dp(82)))
        content = FrameLayout(this)
        shell.addView(content, LinearLayout.LayoutParams(-1,0,1f))
        shell.addView(bottomNav(), LinearLayout.LayoutParams(-1, dp(76)))
        root.addView(shell, FrameLayout.LayoutParams(-1,-1))
        setContentView(root)
        showHome()
    }

    private fun topBar(): View {
        val bar = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(dp(18),dp(10),dp(12),dp(8)); setBackgroundColor(paper) }
        val logo=ImageView(this).apply{setImageResource(R.drawable.ic_app_logo)}
        bar.addView(logo,LinearLayout.LayoutParams(dp(44),dp(44)))
        val texts=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),0,0,0);gravity=Gravity.CENTER_VERTICAL}
        title=TextView(this).apply{text="Bab Ul Ilm";textSize=18f;setTextColor(ink);setTypeface(Typeface.DEFAULT,Typeface.BOLD)}
        subtitle=TextView(this).apply{text="Raza E Mustafa";textSize=11f;setTextColor(muted)}
        texts.addView(title);texts.addView(subtitle);bar.addView(texts,LinearLayout.LayoutParams(0,-1,1f))
        val search=TextView(this).apply{text="⌕";textSize=27f;gravity=Gravity.CENTER;setTextColor(ink);setOnClickListener{showExplore()}}
        bar.addView(search,LinearLayout.LayoutParams(dp(48),dp(48)))
        return bar
    }

    private fun bottomNav(): View {
        val bar=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER;setPadding(dp(8),dp(5),dp(8),dp(7));setBackgroundColor(surface)}
        nav(bar,"⌂","Home"){showHome()};nav(bar,"◈","Explore"){showExplore()};nav(bar,"▤","Library"){openSite("#e-library","E-Library")};nav(bar,"◆","Events"){openSite("#competitions","Events")};nav(bar,"☻","Profile"){showProfile()}
        return bar
    }
    private fun nav(bar:LinearLayout,icon:String,label:String,action:()->Unit){
        val item=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setOnClickListener{action()}}
        item.addView(TextView(this).apply{text=icon;textSize=21f;gravity=Gravity.CENTER;setTextColor(violet)},LinearLayout.LayoutParams(-1,dp(31)))
        item.addView(TextView(this).apply{text=label;textSize=10f;gravity=Gravity.CENTER;setTextColor(muted);setTypeface(Typeface.DEFAULT,Typeface.BOLD)},LinearLayout.LayoutParams(-1,dp(20)))
        bar.addView(item,LinearLayout.LayoutParams(0,-1,1f))
    }

    private fun showHome(){
        title.text="Bab Ul Ilm";subtitle.text="Raza E Mustafa"
        content.removeAllViews()
        val scroll=ScrollView(this).apply{setBackgroundColor(paper)}
        val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(6),dp(18),dp(26))}
        col.addView(TextView(this).apply{text="Assalamu Alaikum";textSize=13f;setTextColor(violet);setTypeface(Typeface.DEFAULT,Typeface.BOLD)},LinearLayout.LayoutParams(-1,dp(28)))
        col.addView(TextView(this).apply{text="Learn. Grow. Serve.";textSize=31f;setTextColor(ink);setTypeface(Typeface.DEFAULT,Typeface.BOLD);setPadding(0,0,0,dp(5))})
        col.addView(TextView(this).apply{text="A modern digital home for Islamic learning, community programs and resources.";textSize=13f;setTextColor(muted);setPadding(0,0,0,dp(16))})
        col.addView(featureCard())
        col.addView(section("Quick access"))
        val grid=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        card(grid,"Islamic Learning","Madarsa, Sunday Schools & camps",violet){openSite("#programs","Learning")}
        card(grid,"Seerat E Nabavi","Competitions, activities & updates",mint){openSite("#competitions","Seerat E Nabavi")}
        card(grid,"Digital Library","Books and Islamic resources",peach){openSite("#e-library","E-Library")}
        card(grid,"Student Portal","Registration and student services",Color.rgb(70,122,190)){openSite("#student-portal","Student Portal")}
        col.addView(grid)
        col.addView(section("Stay connected"))
        col.addView(cta("Visit the complete website","Access every service and section",ink){openSite("","Website")})
        scroll.addView(col);content.addView(scroll,FrameLayout.LayoutParams(-1,-1))
    }

    private fun featureCard():View{
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(20),dp(20),dp(20),dp(18));background=rounded(ink,28)}
        card.addView(TextView(this).apply{text="BAB UL ILM";textSize=11f;setTextColor(mint);setTypeface(Typeface.DEFAULT,Typeface.BOLD)})
        card.addView(TextView(this).apply{text="Raza E Mustafa";textSize=25f;setTextColor(Color.WHITE);setTypeface(Typeface.DEFAULT,Typeface.BOLD);setPadding(0,dp(4),0,dp(6))})
        card.addView(TextView(this).apply{text="Authentic knowledge • character • community";textSize=13f;setTextColor(Color.WHITE);alpha=.82f})
        val b=cta("Explore now","",violet){openSite("","Home")};card.addView(b,LinearLayout.LayoutParams(-1,dp(56)))
        return card.apply{layoutParams=LinearLayout.LayoutParams(-1,dp(210)).also{it.bottomMargin=dp(18)}}
    }

    private fun showExplore(){
        title.text="Explore";subtitle.text="Everything in one place";content.removeAllViews()
        val scroll=ScrollView(this).apply{setBackgroundColor(paper)}
        val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(10),dp(18),dp(25))}
        col.addView(TextView(this).apply{text="Discover";textSize=27f;setTextColor(ink);setTypeface(Typeface.DEFAULT,Typeface.BOLD)})
        col.addView(TextView(this).apply{text="Choose where you want to go.";textSize=13f;setTextColor(muted);setPadding(0,dp(4),0,dp(18))})
        val items=arrayOf("About Us" to "Vision, mission and institution","Programs" to "Education and community initiatives","Competitions" to "Seerat E Nabavi and other events","Gallery" to "Photos and memories","Donate" to "Support the institution","Contact" to "Reach us and find information","Admin" to "Administration portal")
        items.forEachIndexed{idx,p-> card(col,p.first,p.second,if(idx%2==0)violet else mint){openSite("#${p.first.lowercase().replace(" ","-")}",p.first)}}
        scroll.addView(col);content.addView(scroll,FrameLayout.LayoutParams(-1,-1))
    }

    private fun showProfile(){
        title.text="Profile";subtitle.text="Your access & settings";content.removeAllViews()
        val scroll=ScrollView(this);val col=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(24))}
        val identity=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(18),dp(18),dp(18),dp(18));background=rounded(surface,24);elevation=dp(2).toFloat()}
        identity.addView(ImageView(this).apply{setImageResource(R.drawable.ic_app_logo)},LinearLayout.LayoutParams(dp(64),dp(64)))
        val tx=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),0,0,0)}
        tx.addView(TextView(this).apply{text="Bab Ul Ilm Raza E Mustafa";textSize=16f;setTextColor(ink);setTypeface(Typeface.DEFAULT,Typeface.BOLD)})
        tx.addView(TextView(this).apply{text="Mahabubnagar • Telangana";textSize=12f;setTextColor(muted);setPadding(0,dp(4),0,0)})
        identity.addView(tx,LinearLayout.LayoutParams(0,-1,1f));col.addView(identity)
        col.addView(section("Account"))
        col.addView(cta("Student Portal","Login, registration and student services",violet){openSite("#student-portal","Student Portal")})
        col.addView(cta("Admin Portal","Administration access",ink){openSite("#admin","Admin")})
        col.addView(section("Institution"))
        col.addView(cta("About the Institution","Vision, mission and services",mint){openSite("#about","About Us")})
        col.addView(cta("Contact & Location","Get in touch",peach){openSite("#contact","Contact")})
        scroll.addView(col);content.addView(scroll,FrameLayout.LayoutParams(-1,-1))
    }

    private fun section(s:String)=TextView(this).apply{text=s;textSize=17f;setTextColor(ink);setTypeface(Typeface.DEFAULT,Typeface.BOLD);setPadding(0,dp(14),0,dp(10));layoutParams=LinearLayout.LayoutParams(-1,dp(55))}

    private fun card(parent:ViewGroup,name:String,desc:String,color:Int,action:()->Unit){
        val box=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(15),dp(13),dp(12),dp(13));background=rounded(surface,22);elevation=dp(1).toFloat();setOnClickListener{action()}}
        val dot=TextView(this).apply{text="•";textSize=30f;gravity=Gravity.CENTER;setTextColor(color)};box.addView(dot,LinearLayout.LayoutParams(dp(38),dp(48)))
        val tx=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(10),0,dp(8),0)}
        tx.addView(TextView(this).apply{text=name;textSize=14.5f;setTextColor(ink);setTypeface(Typeface.DEFAULT,Typeface.BOLD)})
        tx.addView(TextView(this).apply{text=desc;textSize=11.5f;setTextColor(muted);setPadding(0,dp(3),0,0)})
        box.addView(tx,LinearLayout.LayoutParams(0,-1,1f));box.addView(TextView(this).apply{text="›";textSize=25f;setTextColor(muted);gravity=Gravity.CENTER},LinearLayout.LayoutParams(dp(28),-1))
        parent.addView(box,LinearLayout.LayoutParams(-1,dp(82)).also{it.bottomMargin=dp(10)})
    }

    private fun cta(name:String,desc:String,color:Int,action:()->Unit):View{
        val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(18),dp(11),dp(18),dp(11));background=rounded(color,20);setOnClickListener{action()}}
        b.addView(TextView(this).apply{text=name;textSize=14.5f;setTextColor(Color.WHITE);setTypeface(Typeface.DEFAULT,Typeface.BOLD)})
        if(desc.isNotEmpty())b.addView(TextView(this).apply{text=desc;textSize=11.5f;setTextColor(Color.WHITE);alpha=.8f;setPadding(0,dp(2),0,0)})
        return b.apply{layoutParams=LinearLayout.LayoutParams(-1,if(desc.isEmpty())56 else 70).also{it.bottomMargin=dp(10)}}
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun openSite(fragment:String,page:String){
        content.removeAllViews();title.text=page;subtitle.text="Bab Ul Ilm Raza E Mustafa"
        webView=WebView(this)
        webView.settings.javaScriptEnabled=true;webView.settings.domStorageEnabled=true;webView.settings.databaseEnabled=true;webView.settings.allowFileAccess=true;webView.settings.allowContentAccess=true
        CookieManager.getInstance().setAcceptCookie(true);CookieManager.getInstance().setAcceptThirdPartyCookies(webView,true)
        webView.webViewClient=object:WebViewClient(){override fun shouldOverrideUrlLoading(v:WebView,r:WebResourceRequest):Boolean{val u=r.url;val h=u.host?:"";return if((u.scheme=="http"||u.scheme=="https")&&(h==host||h.endsWith(".$host")))false else{try{startActivity(Intent(Intent.ACTION_VIEW,u))}catch(_:Exception){};true}}}
        webView.webChromeClient=object:WebChromeClient(){override fun onShowFileChooser(v:WebView?,cb:ValueCallback<Array<Uri>>?,p:FileChooserParams?):Boolean{fileCallback?.onReceiveValue(null);fileCallback=cb;return try{startActivityForResult(p?.createIntent()?:Intent(Intent.ACTION_GET_CONTENT).apply{type="*/*";addCategory(Intent.CATEGORY_OPENABLE)},fileRequest);true}catch(_:Exception){fileCallback=null;false}}}
        content.addView(webView,FrameLayout.LayoutParams(-1,-1));webView.loadUrl(site+fragment)
    }

    private fun rounded(color:Int,radius:Int)=GradientDrawable().apply{setColor(color);cornerRadius=dp(radius).toFloat()}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==fileRequest){val r=if(resultCode==Activity.RESULT_OK&&data?.data!=null)arrayOf(data.data!!)else null;fileCallback?.onReceiveValue(r);fileCallback=null}}
    override fun onBackPressed(){if(::webView.isInitialized&&webView.parent!=null){(webView.parent as ViewGroup).removeView(webView);showHome()}else super.onBackPressed()}
    override fun onDestroy(){if(::webView.isInitialized)webView.destroy();fileCallback?.onReceiveValue(null);super.onDestroy()}
}
