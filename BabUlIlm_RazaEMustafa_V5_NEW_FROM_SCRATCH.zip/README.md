# Bab Ul Ilm Raza E Mustafa — V5

Fresh-from-scratch Android app shell with a new visual identity and native-style navigation.

## Build
GitHub Actions builds a debug APK from the repository root using JDK 17 and Gradle 8.9.

## Package
`com.babulilmrazaemustafa.app`
